const jwt = require('jsonwebtoken');

const generateToken = (id, role, sessionId) => {
  return jwt.sign({ id, role, sessionId }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });
};


const verifyToken = (token) => {
  return jwt.verify(token, process.env.JWT_SECRET);
};

module.exports = { generateToken, verifyToken };
